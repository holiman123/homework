package com.company;

import java.util.Scanner;
import java.io.*;

public class Main {
    static double x1;
    static double x2;
    public static void main(String[] args)
    {
        do {
            Scanner sc = new Scanner(System.in);
            int flag;
            System.out.println("выберите действие:\n1 - чётное или не чётное число \n2 - ближайшее к 10 число \n3 - решение квадратичного уровнения");
            flag = sc.nextInt();
            if (flag == 1)
            {
                System.out.println("введите число: ");
                int ch = sc.nextInt();
                if(ch%2 == 1)
                    System.out.println("ваше число не является чётным.\n");
                else
                    System.out.println("ваше число является чётным.\n");
            }
            if (flag == 2)
            {
                System.out.println("ввидите два числа");
                int second1 = sc.nextInt();
                int second2 = sc.nextInt();
                if(Math.abs(second1 - 10) < Math.abs(second2 - 10))
                {
                    System.out.println("первое число ближе к 10 чем второе\n");
                }
                else
                {
                    System.out.println("второе число ближе к 10 чем первое\n");
                }
            }
            if (flag == 3)
            {
                System.out.println("введите уровнение\nпример: ax²+bx+c=0 (квадрат первого Х-а, можно записать в виде обычной двойки)");
                String eq = (sc.next());
                String[] h = new String[10];
                h = eq.split("");
                double D = Math.pow(Integer.parseInt(h[4]) ,2) - 4*Integer.parseInt(h[0]) * Integer.parseInt(h[7]);
                if(D < 0)
                    System.out.println("уровнение корней не имеет");
                else
                {
                    x1 = (-Integer.parseInt(h[4]) + Math.sqrt(D)) / (2*Integer.parseInt(h[0]));
                    x2 = (-Integer.parseInt(h[4]) - Math.sqrt(D)) / (2*Integer.parseInt(h[0]));
                    System.out.println("Корни уравнения:\n");
                    System.out.format("%.2f%n",x1);
                    System.out.format("%.2f%n",x2);
                    System.out.println("\n");
                }
            }
        } while (true);
    }
}
