package List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Main{
    public static void main(String[] args) {
        ArrayList<String> strings = new ArrayList<String>();
        strings.add("Петя");
        strings.add("Вова");
        strings.add("Катя");
        strings.add("Саша");
        strings.add("Коля");
        Collections.sort(strings, new MyComparator());
        for (String Name:strings) {
            System.out.println(Name);
        }
    }
}
class MyComparator implements java.util.Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((String)o2).compareTo((String)o1);
    }
}