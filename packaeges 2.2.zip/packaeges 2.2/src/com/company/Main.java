package com.company;
import pac2.countOfPeople;
import pac3.VinANDcherANDkir;

public class Main {

    public static void main(String[] args) {
        VinANDcherANDkir vck = new VinANDcherANDkir();
        countOfPeople cop = new countOfPeople();
        cop.counCK();
        System.out.println("---------------------");
        cop.counzv();
        System.out.println("---------------------");
        vck.count();
    }
}
