package practiceWork;

public class Main {
    public static void main(String[] args) {
        MotherParrot[] MotherP = new MotherParrot[3];
        MotherP[0] = new MotherParrot(4,10);
        MotherP[1] = new MotherParrot(5,11);
        MotherP[2] = new MotherParrot(3,7);
        MotherParrot TestPa = (MotherP[0].MakeMKP());
        ((MaleKidParrot) TestPa).Fly();
        if(TestPa instanceof MaleKidParrot)
        {
            System.out.println("TestPa is Male Kid Parrot");
        }
        if(TestPa instanceof FemaleKidParrot)
        {
            System.out.println("TestPa is Female Kid Parrot");
        }
    }
    void Parrotsize(Object Parrot)
    {
        System.out.println(((MotherParrot)Parrot).size);
    }

}
class MotherParrot
{
    int age;
    int size;

    public MotherParrot(int age, int size) {
        this.age = age;
        this.size = size;
    }
    MaleKidParrot MakeMKP()
    {
        return new MaleKidParrot(1,4,false);
    }
    FemaleKidParrot MakeFKP()
    {
        return new FemaleKidParrot(2,5,true);
    }
}
class MaleKidParrot extends MotherParrot
{
    boolean isCanFly;

    public MaleKidParrot(int age, int size, boolean isPeted) {
        super(age,size);
        this.isCanFly = isPeted;
    }
    void Fly()
    {
        if(isCanFly)
        {
            System.out.println("Flying around the room.");
        }
        else
        {
            System.out.println("learning to fly");
        }
    }
}
class FemaleKidParrot extends MotherParrot
{
    boolean isCanFly;

    public FemaleKidParrot(int age, int size, boolean isPeted) {
        super(age, size);
        this.isCanFly = isPeted;
    }
    void Fly(boolean isCanFly)
    {
        if(isCanFly)
        {
            System.out.println("Flying around the room.");
        }
        else
        {
            System.out.println("learning to fly");
        }
    }
}
