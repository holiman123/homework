package LuchitskiyCompany;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Chek ch = new Chek("Mr.Roma",4,999999);
        System.out.println(ch.toString());
    }
}
class Chek
{
    String name;
    int HowMany;
    double price;

    public Chek(String name, int howMany, double price) {
        this.name = name;
        HowMany = howMany;
        this.price = price;
    }

    @Override
    public String toString() {
        return "        CHECK:          " +
                "\n========================" +
                "\nYour name: " + name +
                "\namount: " + HowMany +
                "\nprice: " + price +
                "\n========================" +
                "\n  Thanks for your money ";
    }
}
