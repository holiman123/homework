package pac2;

public class cherANDkir {
    public void countcherANDkir()
    {
        countOfPeople cop = new countOfPeople();
        System.out.println(cop.cher + cop.kir);
    }
}
