package pac3;
import pac2.countOfPeople;

public class VinANDcherANDkir {
    public void count()
    {
        countOfPeople cop = new countOfPeople();
        System.out.println(cop.vin + cop.kir + cop.cher);
    }
}
