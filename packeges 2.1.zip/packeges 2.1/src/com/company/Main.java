package com.company;

import java.lang.reflect.Array;
import java.util.Random;

public class Main {

    public static void main(String[] args){
        int[] mas = new int[10];
        Random r = new Random();
        for (int i = 0; i < mas.length; i++) {
            mas[i] = r.nextInt(100);
            System.out.println(mas[i]);
        }
        System.out.println("------------------");
        mas = Sort(mas);
        for (int i = 0; i < mas.length; i++) {
            System.out.println(mas[i]);
        }
    }
    public static int[] Sort (int[] in)
    {
        int minl = in[0];
        int k = 0;
        for (int j = 0; j < in.length - k; j++) {
            for (int i = 0; i < in.length - 1; i++) {
                if (in[i] < in[i + 1]) {
                    int p = in[i];
                    in[i] = in[i + 1];
                    in[i + 1] = p;
                }
            }
            k++;
        }
        return in;
    }
}
