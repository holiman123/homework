package pac2;

public class countOfPeople {
    public int cher = 500000;
    public int vin = 300000;
    public int kir = 250000;
    public int zhit = 200000;

    public void counCK()
    {
        cherANDkir ck = new cherANDkir();
        ck.countcherANDkir();
    }
    public void counzv()
    {
        ZHitANDVin zv = new ZHitANDVin();
        zv.countzhitANDvin();
    }
}
