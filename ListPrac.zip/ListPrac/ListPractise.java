package ListPrac;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class ListPractise {
    public static void main(String[] args) {
        ArrayList<Rocket> RocketList = new ArrayList<Rocket>();
        RocketList.add(new Rocket("BangMen",1.7,1500,true));
        RocketList.add(new Rocket("spaceX",36.9,50000,true));
        RocketList.add(new Rocket("Nasa",28.4,34000,true));
        RocketList.add(new Rocket("Vasy",0.6,200,false));

        do {
            System.out.println("waiting for number (1,2,3,4...)");
            Scanner sc = new Scanner(System.in);
            String c = sc.next();
            switch (c) {
                case "1": {
                    System.out.println("sorting by Makers");
                    Collections.sort(RocketList, new CompareByMakers());
                    break;
                }
                case "2": {
                    System.out.println("sorting by Size");
                    Collections.sort(RocketList, new CompareBySize());
                    break;
                }
                case "3": {
                    System.out.println("sorting by Power");
                    Collections.sort(RocketList, new CompareByPower());
                    break;
                }
                case "4": {
                    System.out.println("sorting by Decupling");
                    Collections.sort(RocketList, new CompareByCowlDecopling());
                    break;
                }
                case "": {
                    System.out.println("sorting by default");
                    Collections.sort(RocketList);
                    break;
                }
                default: {
                    System.out.println("sorting by default");
                    Collections.sort(RocketList);
                    break;
                }
            }
            for (Rocket r : RocketList) {
                System.out.println(r.toString());
            }
        }while (true);
    }
}

class Rocket implements Comparable
{
    String Makers;
    double size;
    int power;
    boolean isCowlDecopls;

    public Rocket(String makers, double size, int power, boolean isCowlDecopls) {
        Makers = makers;
        this.size = size;
        this.power = power;
        this.isCowlDecopls = isCowlDecopls;
    }

    @Override
    public String toString() {
        return "Rocket{" +
                "Makers= " + Makers +
                ", size= " + size +
                ", power= " + power +
                ", isCowlDecopls= " + isCowlDecopls +
                '}';
    }

    @Override
    public int compareTo(Object o) {
        return this.Makers.compareTo(((Rocket)o).Makers);
    }
}

class CompareByMakers implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((Rocket)o1).Makers.compareTo(((Rocket)o2).Makers);
    }
}

class CompareBySize implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return (int)(((Rocket)o2).size - (((Rocket)o1).size));
    }
}

class CompareByPower implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((Rocket)o2).power - (((Rocket)o1).power);
    }
}

class CompareByCowlDecopling implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        if(((Rocket)o1).isCowlDecopls != ((Rocket)o1).isCowlDecopls)
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }
}
