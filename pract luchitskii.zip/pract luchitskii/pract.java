package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class pract {
    public static void main(String[] args) {
        chocolad[] c = {
                new chocolad("Millenium",50,90,"chototam") //1
                ,new chocolad("Roshen",35,100,"Chayka")//2
                ,new chocolad("Milka",42,110,"cherry")//3
                ,new chocolad("Mars incorparated",20,50,"snikers")//4
                ,new chocolad("Mars incorporated",25,50,"Mars")//5
                ,new chocolad("Twix",30,70,"Twix Max")//6
                ,new chocolad("Ferrero",60,150,"ferrero rosher")//7
                ,new chocolad("Nestle",40,100,"KitKat")//8
                ,new chocolad("Mars Incorporated",30,90,"Bounty")//9
                ,new chocolad("Mars Incorporated",40,80,"MilkyWay")//10

        };
        Arrays.sort(c);
        for(int i = 0; i < c.length;i++)
        {
            System.out.println(c[i].toString());
        }

        System.out.println("------------------------------");

        Scanner sc = new Scanner(System.in);
        System.out.println("waiting (1,2,3,4) for sort...");
        String flag = sc.next();
        switch (flag)
        {
            case "1":
            {
                System.out.println("sorting by maker...");
                Arrays.sort(c, new CompByMakerCH());
                break;
            }
            case "2":
            {
                System.out.println("sorting by name...");
                Arrays.sort(c, new CompByNameCH());
                break;
            }
            case "3":
            {
                System.out.println("sorting by weight...");
                Arrays.sort(c, new CompByWeightCH());
                break;
            }
            case "4":
            {
                System.out.println("sorting by price...");
                Arrays.sort(c, new CompByPriceCH());
                break;
            }
            default:
            {
                System.out.println("sotring by default settings...");
                Arrays.sort(c,new CompByMakerCH());
                break;
            }
        }
        for(int i = 0; i < c.length;i++)
        {

            System.out.println("--------------------\n" + c[i].toString());
        }
    }
}
class chocolad implements Comparable
{
    String maker;
    int price;
    int weight;
    String name;

    public chocolad(String maker, int price, int weight, String name) {
        this.maker = maker;
        this.price = price;
        this.weight = weight;
        this.name = name;
    }

    @Override
    public String toString() {
        return "chocolad{" +
                "maker='" + maker + '\'' +
                ", price=" + price +
                ", weight=" + weight +
                ", name='" + name + '\'' +
                '}';
    }
    public int compareTo(Object o) {
        int temp = this.maker.compareTo(((chocolad)o).maker);
        int temp2 = this.price - ((chocolad)o).price;
        int tems3 = this.weight - (((chocolad)o).weight);
        int tems4 = this.name.compareTo(((chocolad)o).name);
        if(temp ==0) {
            if (temp2 == 0) {
                if (tems3 == 0) {
                    if (tems4 == 0) {
                        System.out.println("they are equals");
                        return 0;
                    } else {
                        return tems4;
                    }
                }
                else
                {
                    return tems3;
                }
            }
            else
            {
                return temp2;
            }
        }
        else
        {
            return temp;
        }

    }

}
class CompByPriceCH implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((chocolad)o1).price - ((chocolad)o2).price;
    }
}
class CompByMakerCH implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((chocolad)o1).maker.compareTo(((chocolad)o2).maker);
    }
}
class CompByWeightCH implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((chocolad)o1).weight - ((chocolad)o2).weight;
    }
}
class CompByNameCH implements Comparator
{
    @Override
    public int compare(Object o1, Object o2) {
        return ((chocolad)o1).name.compareTo(((chocolad)o2).name);
    }
}