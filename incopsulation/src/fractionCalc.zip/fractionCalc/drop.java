package fractionCalc;

public class drop {

    public int chislitel;
    public int snamenatel;


    public drop(int ch, int snam)
    {
        chislitel = ch;
        snamenatel = snam;
    }

}
