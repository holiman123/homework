package fractionCalc;

public class view {

    static public void showRes(drop res)
    {
        System.out.println(" " + res.chislitel + "\n-----\n" + " " + res.snamenatel + "\n");
    }

}
